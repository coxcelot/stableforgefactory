# StableForgeFactory Frontend

This folder contains a minimal static frontend for the StableForgeFactory project.

- Live site: https://<your-github-username>.github.io/<your-repo-name>/
- The Pages deploy workflow will automatically inject the deployed factory address into `index.html` if a `stableforge-deploy` artifact (containing `deploy.out`) is available from the deployment workflow.

To preview locally, open `frontend/index.html` in your browser.
